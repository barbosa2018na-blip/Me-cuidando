# MedCuidado — App Android Nativo
## Como compilar e instalar no celular

---

## ✅ O que este app faz de nativo (sem custo)

| Recurso            | Como funciona                                      |
|--------------------|---------------------------------------------------|
| ⏰ Alarme nativo   | AlarmManager do Android — toca mesmo com app fechado |
| 📳 Notificação visor | Aparece na tela bloqueada com heads-up banner    |
| 📱 SMS real        | SmsManager — envia direto sem abrir app de SMS    |
| 📷 OCR câmera      | ML Kit do Google — offline, gratuito, sem API key |
| 🔁 Após reinício   | BootReceiver restaura todos os alarmes automaticamente |

---

## 📋 Pré-requisitos (todos gratuitos)

1. **Android Studio** — baixe em https://developer.android.com/studio
2. **JDK 8+** — já vem junto com o Android Studio
3. **Celular Android** com modo desenvolvedor ativado (ou emulador)

---

## 🚀 Passo a passo para compilar

### 1. Abrir o projeto
- Abra o Android Studio
- Clique em **"Open"**
- Selecione a pasta **MedCuidadoAndroid** (esta pasta)
- Aguarde o Gradle sincronizar (1-3 minutos na primeira vez)

### 2. Conectar o celular
- No celular: **Configurações → Sobre o telefone → Número de compilação** (toque 7 vezes)
- Isso ativa o **Modo Desenvolvedor**
- Vá em **Configurações → Opções do desenvolvedor → Depuração USB** → Ativar
- Conecte o cabo USB no computador
- Aceite a permissão que aparecer na tela do celular

### 3. Instalar no celular
- No Android Studio, selecione seu celular no menu suspenso do topo
- Clique no botão ▶️ **Run** (ou pressione Shift+F10)
- O app será instalado e abrirá automaticamente

---

## 📦 Gerar APK para distribuir

1. No Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. O APK será gerado em:
   `app/build/outputs/apk/debug/app-debug.apk`
3. Envie esse arquivo por WhatsApp, e-mail ou pendrive para instalar em outros celulares

> **Para instalar APK de fora da Play Store:**
> Celular → Configurações → Segurança → **Fontes desconhecidas** → Ativar

---

## ⚙️ Permissões que o app pede ao usuário

| Permissão      | Por quê                              |
|----------------|--------------------------------------|
| SMS            | Enviar alertas para cuidadores       |
| Câmera         | OCR de receitas                      |
| Notificações   | Alertas de medicamentos              |
| Alarmes exatos | Tocar no horário certo               |

---

## 🔔 Como os alarmes funcionam

O app agenda um `AlarmManager` para cada horário de cada remédio.
Quando dispara:
1. Toca som + vibra o celular
2. Mostra notificação no visor (mesmo com tela bloqueada)
3. Envia SMS para todos os cuidadores cadastrados
4. Reagendar automaticamente para o dia seguinte

Se o celular for reiniciado, o `BootReceiver` restaura todos os alarmes.

---

## 🆓 Custos

- Android Studio: **GRATUITO**
- ML Kit OCR: **GRATUITO** (funciona offline)
- AlarmManager: **GRATUITO** (API nativa Android)
- SmsManager: **GRATUITO** (usa o plano SMS do chip do usuário)
- Publicar na Play Store: **US$ 25** (taxa única — opcional)

---

## ❓ Dúvidas frequentes

**O alarme toca com o celular no silencioso?**
Sim, pois é uma notificação de alta prioridade (IMPORTANCE_HIGH).

**Funciona offline?**
Sim completamente. Nenhuma função principal precisa de internet.

**O SMS é cobrado?**
Usa o plano SMS do chip do usuário. A maioria dos planos inclui SMS ilimitado.
