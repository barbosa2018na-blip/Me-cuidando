package br.com.medcuidado;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String nome = intent.getStringExtra("nome");
        String dose = intent.getStringExtra("dose");
        int id = intent.getIntExtra("id", 0);

        if (nome == null) return;

        // 1. Notificação no visor (funciona com tela bloqueada)
        NotificationHelper.mostrar(context,
            "💊 Hora do Remédio!",
            nome + " — " + dose + ". Toque para abrir.");

        // 2. Vibração
        android.os.Vibrator v = (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                v.vibrate(android.os.VibrationEffect.createWaveform(
                    new long[]{0,500,200,500,200,500}, -1));
            } else {
                v.vibrate(new long[]{0,500,200,500,200,500}, -1);
            }
        }

        // 3. Notificar cuidadores via ntfy.sh (grátis, sem SMS, sem permissões extras)
        final String msgFinal = "💊 Hora do remédio: " + nome + " — " + dose;
        SharedPreferences prefs = context.getSharedPreferences("cuidadores", Context.MODE_PRIVATE);
        String cuidadoresJson = prefs.getString("lista", "");
        if (!cuidadoresJson.isEmpty()) {
            // Roda em thread separada para não bloquear o BroadcastReceiver
            new Thread(() -> {
                try {
                    org.json.JSONArray lista = new org.json.JSONArray(cuidadoresJson);
                    for (int i = 0; i < lista.length(); i++) {
                        org.json.JSONObject c = lista.getJSONObject(i);
                        String canal = c.optString("ntfy", "").trim();
                        if (!canal.isEmpty()) {
                            enviarNtfy(canal, "💊 MedCuidado — Hora do Remédio", msgFinal);
                        }
                    }
                } catch (Exception ignored) {}
            }).start();
        }

        // 4. Reagendar para o próximo dia
        SharedPreferences alarmes = context.getSharedPreferences("alarmes", Context.MODE_PRIVATE);
        String dados = alarmes.getString("alarme_" + id, "");
        if (!dados.isEmpty()) {
            String[] parts = dados.split("\\|");
            if (parts.length >= 4) {
                try {
                    int hora = Integer.parseInt(parts[2]);
                    int minuto = Integer.parseInt(parts[3]);
                    android.app.AlarmManager am =
                        (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                    Intent nextIntent = new Intent(context, AlarmReceiver.class);
                    nextIntent.putExtra("id", id);
                    nextIntent.putExtra("nome", parts[0]);
                    nextIntent.putExtra("dose", parts[1]);
                    android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                        context, id, nextIntent,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT |
                        android.app.PendingIntent.FLAG_IMMUTABLE
                    );
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                    cal.set(java.util.Calendar.HOUR_OF_DAY, hora);
                    cal.set(java.util.Calendar.MINUTE, minuto);
                    cal.set(java.util.Calendar.SECOND, 0);
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        am.setExactAndAllowWhileIdle(
                            android.app.AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    } else {
                        am.setExact(android.app.AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    }
                } catch (Exception ignored) {}
            }
        }

        // 5. Notifica o WebView se estiver aberto
        if (MainActivity.staticWebView != null) {
            String js = "if(window.alarmeAndroidDisparou) window.alarmeAndroidDisparou('" +
                nome.replace("'", "\\'") + "', '" + dose.replace("'", "\\'") + "')";
            MainActivity.staticWebView.post(() ->
                MainActivity.staticWebView.evaluateJavascript(js, null));
        }
    }

    /**
     * Envia notificação push via ntfy.sh — completamente gratuito, sem conta, sem permissões
     */
    private void enviarNtfy(String canal, String titulo, String mensagem) {
        try {
            URL url = new URL("https://ntfy.sh/" + canal);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestProperty("Title", titulo);
            conn.setRequestProperty("Priority", "high");
            conn.setRequestProperty("Tags", "pill,bell");
            conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");

            byte[] body = mensagem.getBytes(StandardCharsets.UTF_8);
            OutputStream os = conn.getOutputStream();
            os.write(body);
            os.flush();
            os.close();

            conn.getResponseCode(); // executa a requisição
            conn.disconnect();
        } catch (Exception ignored) {
            // Sem internet no momento — ignora silenciosamente
        }
    }
}
