package br.com.medcuidado;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String nome = intent.getStringExtra("nome");
        String dose = intent.getStringExtra("dose");
        int id = intent.getIntExtra("id", 0);

        if (nome == null) return;

        // 1. Notificação no visor (funciona com tela bloqueada)
        NotificationHelper.mostrar(context,
            "💊 Hora do Remédio!",
            nome + " — " + dose + ". Toque para abrir.");

        // 2. Vibração
        android.os.Vibrator v = (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                v.vibrate(android.os.VibrationEffect.createWaveform(
                    new long[]{0,500,200,500,200,500}, -1));
            } else {
                v.vibrate(new long[]{0,500,200,500,200,500}, -1);
            }
        }

        // 3. Aviso para cuidadores (SMS se permitido, WhatsApp como fallback)
        SharedPreferences prefs = context.getSharedPreferences("cuidadores", Context.MODE_PRIVATE);
        String cuidadoresJson = prefs.getString("lista", "");
        if (!cuidadoresJson.isEmpty()) {
            try {
                org.json.JSONArray lista = new org.json.JSONArray(cuidadoresJson);
                String msg = "💊 MedCuidado: Hora do remédio " + nome + " — " + dose;
                boolean temSms = ContextCompat.checkSelfPermission(context,
                    android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

                for (int i = 0; i < lista.length(); i++) {
                    org.json.JSONObject c = lista.getJSONObject(i);
                    String tel = c.getString("tel").replaceAll("[^0-9+]", "");
                    if (tel.isEmpty()) continue;

                    if (temSms) {
                        // Envia SMS real — Android 12+ usa getSystemService
                        try {
                            SmsManager sms;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                                sms = (SmsManager) context.getSystemService(SmsManager.class);
                            } else {
                                sms = SmsManager.getDefault();
                            }
                            if (sms != null) sms.sendTextMessage(tel, null, msg, null, null);
                        } catch (Exception ignored) {
                            enviarWhatsApp(context, tel, msg);
                        }
                    } else {
                        // SMS bloqueado: abre WhatsApp automaticamente
                        enviarWhatsApp(context, tel, msg);
                    }
                }
            } catch (Exception ignored) {}
        }

        // 4. Reagendar para o próximo dia (alarme diário)
        SharedPreferences alarmes = context.getSharedPreferences("alarmes", Context.MODE_PRIVATE);
        String dados = alarmes.getString("alarme_" + id, "");
        if (!dados.isEmpty()) {
            String[] parts = dados.split("\\|");
            if (parts.length >= 4) {
                try {
                    int hora = Integer.parseInt(parts[2]);
                    int minuto = Integer.parseInt(parts[3]);
                    android.app.AlarmManager am =
                        (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                    Intent nextIntent = new Intent(context, AlarmReceiver.class);
                    nextIntent.putExtra("id", id);
                    nextIntent.putExtra("nome", parts[0]);
                    nextIntent.putExtra("dose", parts[1]);
                    android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(
                        context, id, nextIntent,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT |
                        android.app.PendingIntent.FLAG_IMMUTABLE
                    );
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
                    cal.set(java.util.Calendar.HOUR_OF_DAY, hora);
                    cal.set(java.util.Calendar.MINUTE, minuto);
                    cal.set(java.util.Calendar.SECOND, 0);
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        am.setExactAndAllowWhileIdle(
                            android.app.AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    } else {
                        am.setExact(android.app.AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    }
                } catch (Exception ignored) {}
            }
        }

        // 5. Notifica o WebView se estiver aberto
        if (MainActivity.staticWebView != null) {
            String js = "if(window.alarmeAndroidDisparou) window.alarmeAndroidDisparou('" +
                nome.replace("'", "\\'") + "', '" + dose.replace("'", "\\'") + "')";
            MainActivity.staticWebView.post(() ->
                MainActivity.staticWebView.evaluateJavascript(js, null));
        }
    }

    /**
     * Abre WhatsApp com mensagem pré-preenchida para o número
     * Funciona mesmo sem permissão de SMS
     */
    private void enviarWhatsApp(Context context, String tel, String mensagem) {
        try {
            // Formata número para WhatsApp (precisa de código do país)
            String numero = tel.startsWith("+") ? tel : "+55" + tel;
            String url = "https://api.whatsapp.com/send?phone=" +
                numero.replaceAll("[^0-9]", "") +
                "&text=" + Uri.encode(mensagem);
            Intent wa = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            wa.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(wa);
        } catch (Exception ignored) {
            // WhatsApp não instalado — só ignora
        }
    }
}
