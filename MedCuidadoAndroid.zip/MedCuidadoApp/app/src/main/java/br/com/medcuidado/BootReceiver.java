package br.com.medcuidado;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.Map;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action) &&
            !"android.intent.action.QUICKBOOT_POWERON".equals(action)) return;

        // Restaura todos os alarmes salvos
        SharedPreferences prefs = context.getSharedPreferences("alarmes", Context.MODE_PRIVATE);
        Map<String, ?> todos = prefs.getAll();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        for (Map.Entry<String, ?> entry : todos.entrySet()) {
            if (!entry.getKey().startsWith("alarme_")) continue;
            try {
                int id = Integer.parseInt(entry.getKey().replace("alarme_", ""));
                String[] parts = entry.getValue().toString().split("\\|");
                if (parts.length < 4) continue;

                String nome = parts[0];
                String dose = parts[1];
                int hora = Integer.parseInt(parts[2]);
                int minuto = Integer.parseInt(parts[3]);

                Intent alarmIntent = new Intent(context, AlarmReceiver.class);
                alarmIntent.putExtra("id", id);
                alarmIntent.putExtra("nome", nome);
                alarmIntent.putExtra("dose", dose);

                PendingIntent pi = PendingIntent.getBroadcast(
                    context, id, alarmIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hora);
                cal.set(Calendar.MINUTE, minuto);
                cal.set(Calendar.SECOND, 0);
                if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                    cal.add(Calendar.DAY_OF_YEAR, 1);
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                }
            } catch (Exception ignored) {}
        }
    }
}
