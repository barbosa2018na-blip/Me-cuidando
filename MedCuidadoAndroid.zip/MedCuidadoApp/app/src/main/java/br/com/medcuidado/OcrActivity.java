package br.com.medcuidado;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

public class OcrActivity extends AppCompatActivity {

    private static final int REQ_CAMERA = 300;
    private ImageView imgPreview;
    private TextView txtResultado;
    private ProgressBar progress;
    private Button btnTirarFoto, btnConfirmar, btnCancelar;
    private Bitmap fotoBitmap;
    private JSONObject dadosExtraidos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocr);

        imgPreview   = findViewById(R.id.imgPreview);
        txtResultado = findViewById(R.id.txtResultado);
        progress     = findViewById(R.id.progress);
        btnTirarFoto = findViewById(R.id.btnTirarFoto);
        btnConfirmar = findViewById(R.id.btnConfirmar);
        btnCancelar  = findViewById(R.id.btnCancelar);

        btnTirarFoto.setOnClickListener(v -> abrirCamera());
        btnCancelar.setOnClickListener(v -> finish());
        btnConfirmar.setOnClickListener(v -> confirmarResultado());

        // Abre câmera automaticamente ao entrar
        abrirCamera();
    }

    private void abrirCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQ_CAMERA);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAMERA && resultCode == Activity.RESULT_OK && data != null) {
            fotoBitmap = (Bitmap) data.getExtras().get("data");
            if (fotoBitmap != null) {
                imgPreview.setImageBitmap(fotoBitmap);
                imgPreview.setVisibility(View.VISIBLE);
                processarOCR(fotoBitmap);
            }
        } else if (requestCode == REQ_CAMERA) {
            finish(); // usuário cancelou câmera
        }
    }

    private void processarOCR(Bitmap bitmap) {
        progress.setVisibility(View.VISIBLE);
        txtResultado.setText("🔍 Analisando imagem...");
        btnConfirmar.setVisibility(View.GONE);

        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
            .addOnSuccessListener(visionText -> {
                progress.setVisibility(View.GONE);
                interpretarTexto(visionText.getText());
            })
            .addOnFailureListener(e -> {
                progress.setVisibility(View.GONE);
                txtResultado.setText("⚠️ Erro na leitura. Tente novamente.");
                btnTirarFoto.setVisibility(View.VISIBLE);
            });
    }

    private void interpretarTexto(String textoCompleto) {
        if (textoCompleto.trim().isEmpty()) {
            txtResultado.setText("⚠️ Nenhum texto encontrado. Tente com mais luz ou mais perto.");
            btnTirarFoto.setVisibility(View.VISIBLE);
            return;
        }

        try {
            dadosExtraidos = new JSONObject();
            String nome = "";
            String dose = "";
            String horarios = "08:00";
            String obs = "";

            String[] linhas = textoCompleto.split("\\n");

            // Detecta nome do remédio (primeira linha com mais de 3 chars em maiúscula ou linha com mg/ml)
            for (String linha : linhas) {
                linha = linha.trim();
                if (linha.length() > 3 && (
                    linha.matches(".*\\d+\\s*mg.*") ||
                    linha.matches(".*\\d+\\s*ml.*") ||
                    linha.matches(".*\\d+\\s*mcg.*") ||
                    linha.matches(".*comprimido.*") ||
                    linha.matches(".*cápsula.*") ||
                    linha.matches(".*solução.*")
                )) {
                    nome = linha;
                    break;
                }
            }
            // fallback: usa primeira linha como nome
            if (nome.isEmpty() && linhas.length > 0) nome = linhas[0].trim();

            // Detecta dosagem (padrões comuns)
            for (String linha : linhas) {
                if (linha.matches(".*\\d+\\s*mg.*|.*\\d+\\s*ml.*|.*\\d+\\s*mcg.*|.*\\d+\\s*UI.*")) {
                    dose = linha.trim();
                    break;
                }
            }
            if (dose.isEmpty()) dose = "Conforme prescrição";

            // Detecta horários (padrão HH:MM)
            java.util.List<String> hsList = new java.util.ArrayList<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b([0-1]?[0-9]|2[0-3]):[0-5][0-9]\\b")
                .matcher(textoCompleto);
            while (m.find()) hsList.add(m.group());
            if (!hsList.isEmpty()) horarios = String.join(", ", hsList);

            // Texto completo como obs
            obs = textoCompleto.replace("\"", "'").replace("\n", " ").trim();
            if (obs.length() > 200) obs = obs.substring(0, 200) + "...";

            dadosExtraidos.put("nome", nome);
            dadosExtraidos.put("dose", dose);
            dadosExtraidos.put("horarios", horarios);
            dadosExtraidos.put("obs", obs);

            txtResultado.setText(
                "✅ Leitura concluída!\n\n" +
                "💊 Nome: " + nome + "\n" +
                "📏 Dose: " + dose + "\n" +
                "⏰ Horários: " + horarios
            );
            btnConfirmar.setVisibility(View.VISIBLE);
            btnTirarFoto.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            txtResultado.setText("⚠️ Erro ao interpretar. Texto lido:\n" + textoCompleto.substring(0, Math.min(textoCompleto.length(), 300)));
            btnTirarFoto.setVisibility(View.VISIBLE);
        }
    }

    private void confirmarResultado() {
        if (dadosExtraidos != null) {
            Intent result = new Intent();
            result.putExtra("ocr_result", dadosExtraidos.toString());
            setResult(Activity.RESULT_OK, result);
        }
        finish();
    }
}
