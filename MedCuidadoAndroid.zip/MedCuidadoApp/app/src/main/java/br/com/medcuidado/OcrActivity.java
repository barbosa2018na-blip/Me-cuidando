package br.com.medcuidado;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

public class OcrActivity extends AppCompatActivity {

    private static final int REQ_CAMERA = 300;
    private static final int REQ_CAMERA_PERMISSION = 301;
    private ImageView imgPreview;
    private TextView txtResultado;
    private ProgressBar progress;
    private Button btnTirarFoto, btnConfirmar, btnCancelar;
    private Bitmap fotoBitmap;
    private JSONObject dadosExtraidos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocr);

        imgPreview   = findViewById(R.id.imgPreview);
        txtResultado = findViewById(R.id.txtResultado);
        progress     = findViewById(R.id.progress);
        btnTirarFoto = findViewById(R.id.btnTirarFoto);
        btnConfirmar = findViewById(R.id.btnConfirmar);
        btnCancelar  = findViewById(R.id.btnCancelar);

        btnTirarFoto.setOnClickListener(v -> verificarPermissaoEAbrirCamera());
        btnCancelar.setOnClickListener(v -> finish());
        btnConfirmar.setOnClickListener(v -> confirmarResultado());

        // Abre câmera automaticamente ao entrar
        verificarPermissaoEAbrirCamera();
    }

    private void verificarPermissaoEAbrirCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Pede permissão de câmera se ainda não tem
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_PERMISSION);
        } else {
            abrirCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                abrirCamera();
            } else {
                Toast.makeText(this, "⚠️ Permissão de câmera necessária para o OCR", Toast.LENGTH_LONG).show();
                txtResultado.setText("⚠️ Permissão de câmera negada.\nVá em Configurações > Apps > MedCuidado > Permissões > Câmera");
                btnTirarFoto.setVisibility(View.VISIBLE);
            }
        }
    }

    private void abrirCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Android 11+: resolveActivity pode retornar null mesmo com câmera disponível
        // Usamos try/catch como fallback seguro
        try {
            startActivityForResult(intent, REQ_CAMERA);
        } catch (Exception e) {
            Toast.makeText(this, "⚠️ Câmera não disponível: " + e.getMessage(), Toast.LENGTH_LONG).show();
            txtResultado.setText("⚠️ Não foi possível abrir a câmera.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAMERA && resultCode == Activity.RESULT_OK && data != null) {
            fotoBitmap = (Bitmap) data.getExtras().get("data");
            if (fotoBitmap != null) {
                imgPreview.setImageBitmap(fotoBitmap);
                imgPreview.setVisibility(View.VISIBLE);
                processarOCR(fotoBitmap);
            }
        } else if (requestCode == REQ_CAMERA) {
            finish(); // usuário cancelou câmera
        }
    }

    private void processarOCR(Bitmap bitmap) {
        progress.setVisibility(View.VISIBLE);
        txtResultado.setText("🔍 Lendo texto da imagem...");
        btnConfirmar.setVisibility(View.GONE);

        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
            .addOnSuccessListener(visionText -> {
                progress.setVisibility(View.GONE);
                interpretarTexto(visionText.getText());
            })
            .addOnFailureListener(e -> {
                progress.setVisibility(View.GONE);
                txtResultado.setText("⚠️ Erro na leitura. Tente novamente com mais luz.");
                btnTirarFoto.setVisibility(View.VISIBLE);
            });
    }

    private void interpretarTexto(String textoCompleto) {
        if (textoCompleto.trim().isEmpty()) {
            txtResultado.setText("⚠️ Nenhum texto encontrado.\nDica: mais luz, mais perto, sem tremor.");
            btnTirarFoto.setVisibility(View.VISIBLE);
            return;
        }

        try {
            dadosExtraidos = new JSONObject();
            String nome = "";
            String dose = "";
            String horarios = "08:00";
            String obs = "";

            String[] linhas = textoCompleto.split("\\n");

            // Detecta nome (linha com mg/ml/comprimido ou primeira linha)
            for (String linha : linhas) {
                linha = linha.trim();
                if (linha.length() > 3 && (
                    linha.matches(".*\\d+\\s*mg.*") ||
                    linha.matches(".*\\d+\\s*ml.*") ||
                    linha.matches(".*\\d+\\s*mcg.*") ||
                    linha.toLowerCase().contains("comprimido") ||
                    linha.toLowerCase().contains("cápsula") ||
                    linha.toLowerCase().contains("solução")
                )) {
                    nome = linha;
                    break;
                }
            }
            if (nome.isEmpty() && linhas.length > 0) nome = linhas[0].trim();

            // Detecta dosagem
            for (String linha : linhas) {
                if (linha.matches(".*\\d+\\s*mg.*|.*\\d+\\s*ml.*|.*\\d+\\s*mcg.*|.*\\d+\\s*UI.*")) {
                    dose = linha.trim();
                    break;
                }
            }
            if (dose.isEmpty()) dose = "Conforme prescrição";

            // Detecta horários (HH:MM)
            java.util.List<String> hsList = new java.util.ArrayList<>();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b([0-1]?[0-9]|2[0-3]):[0-5][0-9]\\b")
                .matcher(textoCompleto);
            while (m.find()) hsList.add(m.group());
            if (!hsList.isEmpty()) horarios = String.join(", ", hsList);

            obs = textoCompleto.replace("\"", "'").replace("\n", " ").trim();
            if (obs.length() > 200) obs = obs.substring(0, 200) + "...";

            dadosExtraidos.put("nome", nome);
            dadosExtraidos.put("dose", dose);
            dadosExtraidos.put("horarios", horarios);
            dadosExtraidos.put("obs", obs);

            txtResultado.setText(
                "✅ Texto lido com sucesso!\n\n" +
                "💊 Nome: " + nome + "\n" +
                "📏 Dose: " + dose + "\n" +
                "⏰ Horários: " + horarios + "\n\n" +
                "Confira os dados antes de confirmar."
            );
            btnConfirmar.setVisibility(View.VISIBLE);
            btnTirarFoto.setVisibility(View.VISIBLE);

        } catch (Exception e) {
            txtResultado.setText("⚠️ Erro ao interpretar.\nTexto lido:\n" +
                textoCompleto.substring(0, Math.min(textoCompleto.length(), 300)));
            btnTirarFoto.setVisibility(View.VISIBLE);
        }
    }

    private void confirmarResultado() {
        if (dadosExtraidos != null) {
            Intent result = new Intent();
            result.putExtra("ocr_result", dadosExtraidos.toString());
            setResult(Activity.RESULT_OK, result);
        }
        finish();
    }
}
