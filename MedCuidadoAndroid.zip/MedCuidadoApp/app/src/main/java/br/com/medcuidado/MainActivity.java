package br.com.medcuidado;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    public static final String CHANNEL_ID = "medcuidado_alertas";
    private static final int REQ_PERMISSIONS = 100;
    private static final int REQ_OCR = 200;
    public static WebView staticWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        criarCanalNotificacao();
        pedirPermissoes();
        configurarWebView();
    }

    private void criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(
                CHANNEL_ID,
                "Alertas de Remédios",
                NotificationManager.IMPORTANCE_HIGH
            );
            canal.setDescription("Lembretes de medicamentos do MedCuidado");
            canal.enableVibration(true);
            canal.setVibrationPattern(new long[]{0, 500, 200, 500, 200, 500});
            canal.setShowBadge(true);
            canal.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);

            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(canal);
        }
    }

    private void pedirPermissoes() {
        // Pede apenas as permissões essenciais na abertura
        // SMS é pedido separadamente com explicação
        java.util.List<String> perms = new java.util.ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.SEND_SMS);
        }
        if (!perms.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                perms.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    private void configurarWebView() {
        webView = findViewById(R.id.webview);
        staticWebView = webView;

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Bridge JavaScript <-> Android
        webView.addJavascriptInterface(new AndroidBridge(this), "Android");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("sms:") || url.startsWith("tel:")) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                    return true;
                }
                return false;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OCR && resultCode == Activity.RESULT_OK && data != null) {
            String resultado = data.getStringExtra("ocr_result");
            if (resultado != null && webView != null) {
                String js = "window.receberResultadoOCR(" + resultado + ")";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ============================================================
    // BRIDGE: funções chamadas pelo JavaScript via Android.xxx()
    // ============================================================
    public class AndroidBridge {
        private final Context ctx;

        AndroidBridge(Context context) { this.ctx = context; }

        /**
         * Agenda alarme nativo do Android
         * JS: Android.agendarAlarme(id, hora, minuto, nomeRemedio, dose)
         */
        @JavascriptInterface
        public void agendarAlarme(int id, int hora, int minuto, String nome, String dose) {
            try {
                AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(ctx, AlarmReceiver.class);
                intent.putExtra("id", id);
                intent.putExtra("nome", nome);
                intent.putExtra("dose", dose);

                PendingIntent pi = PendingIntent.getBroadcast(
                    ctx, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hora);
                cal.set(Calendar.MINUTE, minuto);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                    cal.add(Calendar.DAY_OF_YEAR, 1);
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (am.canScheduleExactAlarms()) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    } else {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                    }
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                }

                // Salva alarme no SharedPreferences para restaurar após reboot
                SharedPreferences prefs = ctx.getSharedPreferences("alarmes", MODE_PRIVATE);
                prefs.edit().putString("alarme_" + id, nome + "|" + dose + "|" + hora + "|" + minuto).apply();

                mostrarToast("⏰ Alarme definido: " + nome + " às " +
                    String.format("%02d:%02d", hora, minuto));
            } catch (Exception e) {
                mostrarToast("Erro ao definir alarme: " + e.getMessage());
            }
        }

        /**
         * Cancela alarme agendado
         * JS: Android.cancelarAlarme(id)
         */
        @JavascriptInterface
        public void cancelarAlarme(int id) {
            try {
                AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
                Intent intent = new Intent(ctx, AlarmReceiver.class);
                PendingIntent pi = PendingIntent.getBroadcast(
                    ctx, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                am.cancel(pi);
                SharedPreferences prefs = ctx.getSharedPreferences("alarmes", MODE_PRIVATE);
                prefs.edit().remove("alarme_" + id).apply();
            } catch (Exception e) {}
        }

        /**
         * Envia SMS automaticamente
         * JS: Android.enviarSMS(numero, mensagem)
         */
        @JavascriptInterface
        public boolean enviarSMS(String numero, String mensagem) {
            try {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Pede permissão ao usuário se ainda não foi concedida
                    ActivityCompat.requestPermissions((Activity) ctx,
                        new String[]{Manifest.permission.SEND_SMS}, REQ_PERMISSIONS);
                    mostrarToast("⚠️ Permissão de SMS necessária. Aceitou? Tente novamente.");
                    return false;
                }
                SmsManager sms = SmsManager.getDefault();
                java.util.ArrayList<String> partes = sms.divideMessage(mensagem);
                sms.sendMultipartTextMessage(numero, null, partes, null, null);
                return true;
            } catch (Exception e) {
                mostrarToast("Erro SMS: " + e.getMessage());
                return false;
            }
        }

        /**
         * Salva lista de cuidadores para o SMS automático no AlarmReceiver
         * JS: Android.salvarCuidadores(jsonArray)
         */
        @JavascriptInterface
        public void salvarCuidadores(String jsonArray) {
            try {
                SharedPreferences prefs = ctx.getSharedPreferences("cuidadores", Context.MODE_PRIVATE);
                prefs.edit().putString("lista", jsonArray).apply();
            } catch (Exception ignored) {}
        }

        /**
         * Lê lista de cuidadores salva
         * JS: Android.lerCuidadores()
         */
        @JavascriptInterface
        public String lerCuidadores() {
            SharedPreferences prefs = ctx.getSharedPreferences("cuidadores", Context.MODE_PRIVATE);
            return prefs.getString("lista", "[]");
        }

        /**
         * Abre câmera com OCR nativo (ML Kit - offline, gratuito)
         * JS: Android.abrirOCR()
         */
        @JavascriptInterface
        public void abrirOCR() {
            Intent intent = new Intent(ctx, OcrActivity.class);
            ((Activity) ctx).startActivityForResult(intent, REQ_OCR);
        }

        /**
         * Mostra notificação no visor (funciona com tela bloqueada)
         * JS: Android.mostrarNotificacao(titulo, texto)
         */
        @JavascriptInterface
        public void mostrarNotificacao(String titulo, String texto) {
            NotificationHelper.mostrar(ctx, titulo, texto);
        }

        /**
         * Vibra o celular
         * JS: Android.vibrar()
         */
        @JavascriptInterface
        public void vibrar() {
            android.os.Vibrator v = (android.os.Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(android.os.VibrationEffect.createWaveform(
                        new long[]{0, 500, 200, 500, 200, 500}, -1));
                } else {
                    v.vibrate(new long[]{0, 500, 200, 500, 200, 500}, -1);
                }
            }
        }

        /**
         * Toast nativo Android
         * JS: Android.toast(mensagem)
         */
        @JavascriptInterface
        public void toast(String msg) { mostrarToast(msg); }

        /**
         * Verifica se o app tem permissão de SMS
         */
        @JavascriptInterface
        public boolean temPermissaoSMS() {
            return ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        }

        private void mostrarToast(final String msg) {
            ((Activity) ctx).runOnUiThread(() ->
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show());
        }
    }
}
